#include<stdio.h>
#include<stdlib.h>
#include"nohead.h"
#define NAMESIZE 32

struct node_st * list_insert(struct node_st *list,struct score_st *data)
{
	struct node_st *new;
	new = malloc(sizeof(*new));
	if(new ==NULL)
		return NULL;
	new->data = *data;//什么意思？数组就打印出去了？
	new->next =list;
	list = new;
	return list;
}
void list_show(struct node_st *list)
{
	struct node_st *cur;
	for(cur=list;cur!=NULL;cur=cur->next)
	{
		printf("%d %s %d %d\n",cur->data.id,cur->data.name,cur->data.math,cur->data.chinese);//因为cur是指针，所以用箭头，data是变量所以用.
	}
}
/*
 
list_delete();
list_find();
*/

